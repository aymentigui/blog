import React from 'react'
import Dashboard from './_components/dashboard';

const AdminPage = () => {

  return (
    <>
      <Dashboard />
    </>
  )
}

export default AdminPage