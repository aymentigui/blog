import React from 'react'

const PrivatePage = () => {
  return (
    <div>
    Hi..
    </div>
  )
}

export default PrivatePage
