import React from 'react'

const CardCategorie = () => {
  return (
    <div>
      
    </div>
  )
}

export default CardCategorie
