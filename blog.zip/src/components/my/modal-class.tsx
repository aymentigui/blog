import React from 'react'

const ModalClass = () => {
  return (
    <div className='hidden'>
        <div className='w-[70%] max-w-[70%] h-[80%] '></div>
        <div className="sm:w-[305px] md:w-[455px] lg:w-[755px] xl:w-[955px]"></div>
    </div>
  )
}

export default ModalClass
